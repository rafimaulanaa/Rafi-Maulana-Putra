import React from 'react';
import { View, FlatList, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

const data = [
  { 
    id: '1', 
    judul: 'Meitiasari Nurlatifah', 
    telpon: '085892775764',
    gambar: require('../assets/Memei.jpeg'),
    alamat: 'Jl. Pelda Suryanta',
  },
  { 
    id: '2', 
    judul: 'Dian Sela Anjelina', 
    telpon: '08156193245', 
    gambar: require('../assets/Dian.jpeg'),
    alamat: 'Jl. Jagaraksa Gang Amris',
  },
  { 
    id: '3', 
    judul: 'Natya Octaviana', 
    telpon: '085721884434', 
    gambar: require('../assets/Natya.jpeg'),
    alamat: 'Jl. Gunung karang,Liung tutut Rt02/Rw09',
  },
  { 
    id: '4', 
    judul: 'Agung Bahtiar', 
    telpon: '087772243468', 
    gambar: require('../assets/Agung.jpeg'),
    alamat: 'Jl. Keramat',
  },
  { 
    id: '5', 
    judul: 'Moch Azkiya', 
    telpon: '085871287578', 
    gambar: require('../assets/Azkiya.jpeg'),
    alamat: 'Jl. Cisaat',
  },
];

const KontakItem = ({ judul, telpon, gambar, alamat, onPress }) => (
  <TouchableOpacity onPress={onPress} style={styles.itemContainer}>
    <Image source={gambar} style={styles.image} />
    <View style={styles.textContainer}>
      <Text style={styles.title}>{judul}</Text>
      <Text style={styles.subtitle}>{telpon}</Text>
      <Text style={styles.address}>{alamat}</Text>
    </View>
  </TouchableOpacity>
);

const Kontak = ({ navigation }) => {
  const renderItem = ({ item }) => (
    <KontakItem
      judul={item.judul}
      telpon={item.telpon}
      gambar={item.gambar}
      alamat={item.alamat}
      onPress={() => navigation.navigate('KontakDetail', item)}
    />
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={data}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderItem}
        contentContainerStyle={styles.flatlistContainer}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F0F0F0', 
  },
  flatlistContainer: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#FFFFFF', 
    marginBottom: 8,
    borderRadius: 8,
    elevation: 2, 
  },
  image: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  textContainer: {
    flex: 1,
    marginLeft: 12,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333', 
  },
  subtitle: {
    fontSize: 16,
    color: '#666666', 
  },
  address: {
    fontSize: 14,
    color: '#999999', 
    marginTop: 4,
  },
});

export default Kontak;
