import React from 'react';
import { View, Text, Image, StyleSheet, Button } from 'react-native';
const KontakDetail = ({ route, navigation }) => {
  const { judul, telpon, gambar } = route.params;

  return (
    <View style={styles.container}>
      <Image source={gambar} style={styles.image} />
      <Text style={styles.title}>{judul}</Text>
      <Text style={styles.phone}>{telpon}</Text>
      <Button
        title="Back to Home"
        onPress={() => navigation.navigate('Home')}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    backgroundColor: '#fff',
  },
  image: {
    width: 100,
    height: 100,
    marginBottom: 20,
    borderRadius: 50,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  phone: {
    fontSize: 20,
    color: '#666',
  },
});

export default KontakDetail;
